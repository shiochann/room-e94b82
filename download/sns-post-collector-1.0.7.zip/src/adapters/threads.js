// Threads用アダプタ。
//
// 設計方針：Threadsのclass名はハッシュ化されていて頻繁に変わるので一切使わない。
// 代わりに意味が変わりにくい足場だけを使う。
//   1. 投稿URL  a[href*="/post/"]      … 投稿の識別子
//   2. 日時     time[datetime]         … 投稿日
//   3. アイコンのaria-label / title    … いいね・返信などの対応付け
//   4. 投稿どうしの共通祖先の広さ      … ツリー1本の境界（collectGroups参照）
//
// 実ページ（2026-08）で確認した事実：
//   - いいねのラベルは「いいね！」（全角カッコと感嘆符付き）
//   - プロフィールにはツリーのパート1〜2が表示され、残りは「他N件を見る」になる
//   - ページ内にはプロフィールの投稿以外（おすすめ等）も混ざり得るので、
//     「フィードの直下の子」のような固定の親要素を基準にしてはいけない
window.SPC = window.SPC || {};
SPC.adapters = SPC.adapters || {};

SPC.adapters.threads = (() => {
  const { parse, looksNumeric } = SPC.num;

  const LABELS = {
    likes: /いいね|like/i,
    replies: /返信|コメント|repl(y|ies)|comment/i,
    reposts: /再投稿|リポスト|repost/i,
    shares: /共有|シェア|送信|share|send/i,
  };

  // 本文として拾いたくないもの（実ページで実際に混ざったものを列挙）
  const NOISE = [
    /^(翻訳を見る|See translation|もっと見る|さらに表示|Show more|返信|Reply|·|・)$/,
    /^(ピン留め済み|Pinned)$/,
    /^\d{4}\/\d{1,2}\/\d{1,2}$/, // 2026/08/05
    /^\d+(秒|分|時間|日|週)$/, // 9分
    /^\d+[smhdw]$/i, // 9m
    /^他\d+件を見る$/,
    /^(Show|View) \d+ more$/i,
    /^\d+\/\d+$/, // パート番号 2/4
  ];
  const isNoise = (t) => NOISE.some((re) => re.test(t));

  const SEE_MORE = [/^他(\d+)件を見る$/, /^(?:Show|View) (\d+) more$/i];
  const PINNED = /^(ピン留め済み|Pinned)$/;

  function isSupported() {
    return /(^|\.)threads\.(com|net)$/.test(location.hostname);
  }

  function profileHandle() {
    const m = location.pathname.match(/^\/@([A-Za-z0-9._]+)/);
    return m ? m[1] : null;
  }

  function detailTarget() {
    const m = location.pathname.match(/^\/@([A-Za-z0-9._]+)\/post\/([A-Za-z0-9_-]+)/);
    return m ? { handle: m[1], code: m[2] } : null;
  }

  function shortcodeOf(href) {
    const m = href.match(/\/@([A-Za-z0-9._]+)\/post\/([A-Za-z0-9_-]+)/);
    return m ? { handle: m[1], code: m[2] } : null;
  }

  function distinctCodes(el) {
    const set = new Set();
    el.querySelectorAll('a[href*="/post/"]').forEach((a) => {
      const s = shortcodeOf(a.getAttribute("href") || "");
      if (s) set.add(s.code);
    });
    return set;
  }

  // その要素が持っている反応アイコン（いいね・返信・再投稿・共有）の種類。
  function metricIconSet(root) {
    const set = new Set();
    root.querySelectorAll("svg").forEach((s) => {
      const key = matchMetric(labelOf(s));
      if (key) set.add(key);
    });
    return set;
  }

  // 日時を起点に、1投稿ぶんの枠を特定する。
  //
  // 以前はパーマリンクを起点に上へ辿っていたが、投稿詳細ページでは
  // 本文の投稿のリンクだけが「スレッド／表示◯回」という別区画の中にあり、
  // そこから上ってもその投稿の枠には決して辿り着けない（実ページで確認）。
  // 結果、本文が「スレッド」だけになり反応数も取れなかった。
  //
  // 日時はどの投稿にも必ず1つあり、反応アイコンの有無で
  // 「本当に投稿の枠か」を確かめられるので、こちらを足場にする。
  function rootFromTime(timeEl) {
    let el = timeEl;
    for (let i = 0; i < 14 && el && el !== document.body; i++) {
      const times = el.querySelectorAll("time[datetime]").length;
      if (times === 1 && metricIconSet(el).size >= 2) return el;
      if (times > 1) break; // 別の投稿を巻き込んだ
      el = el.parentElement;
    }
    return null;
  }

  function labelOf(el) {
    const candidates = [
      el.getAttribute && el.getAttribute("aria-label"),
      el.querySelector && el.querySelector("title") ? el.querySelector("title").textContent : null,
      el.closest && el.closest("[aria-label]") ? el.closest("[aria-label]").getAttribute("aria-label") : null,
    ];
    return candidates.find((c) => c && c.trim()) || "";
  }

  function matchMetric(label) {
    for (const [key, re] of Object.entries(LABELS)) {
      if (re.test(label)) return key;
    }
    return null;
  }

  // 数値の抽出は2段構え。
  //   1段目: aria-label自体に数が入っているケース
  //   2段目: アイコンを見つけたら、その直後に現れる数値を割り当てる
  //           （0件は数値が描画されないので、位置での対応付けはしない）
  function extractMetrics(root) {
    const out = { likes: null, replies: null, reposts: null, shares: null };

    root.querySelectorAll("[aria-label]").forEach((el) => {
      const label = el.getAttribute("aria-label") || "";
      const key = matchMetric(label);
      if (!key || out[key] != null) return;
      if (/\d/.test(label)) {
        const n = parse(label);
        if (n != null) out[key] = n;
      }
    });

    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
      null
    );
    let current = null;
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node.nodeType === Node.ELEMENT_NODE) {
        if (node.tagName.toLowerCase() === "svg") {
          const key = matchMetric(labelOf(node));
          if (key) current = key;
        }
        continue;
      }
      const text = (node.textContent || "").trim();
      if (!text || !current) continue;
      if (looksNumeric(text)) {
        if (out[current] == null) out[current] = parse(text);
        current = null;
      }
    }

    // アイコンは見つかったが数値が無かった項目は0件とみなす。
    // アイコン自体が無かった場合は null のまま（＝取得失敗）にして警告できるようにする。
    const iconKeys = new Set();
    root.querySelectorAll("svg").forEach((s) => {
      const key = matchMetric(labelOf(s));
      if (key) iconKeys.add(key);
    });
    for (const key of iconKeys) {
      if (out[key] == null) out[key] = 0;
    }

    return { metrics: out, foundIcons: [...iconKeys] };
  }

  // リンクプレビューカード（画像付きの外部リンク）の中の文字は本文ではない
  function inLinkCard(el) {
    const a = el.closest('a[href^="http"]');
    return !!(a && !/threads\.(com|net)/.test(a.getAttribute("href") || "") && a.querySelector("img"));
  }

  function extractText(root) {
    const nodes = [...root.querySelectorAll('[dir="auto"]')].filter((el) => {
      if (el.closest('a[href^="/@"]:not([href*="/post/"])')) return false; // ヘッダーのハンドル
      if (el.querySelector('[dir="auto"]')) return false; // 入れ子の親は除外（重複防止）
      if (el.closest("time")) return false;
      if (inLinkCard(el)) return false;
      const t = (el.textContent || "").trim();
      if (!t || isNoise(t)) return false;
      if (looksNumeric(t)) return false;
      return true;
    });

    const seen = new Set();
    const parts = [];
    for (const el of nodes) {
      // 末尾に紛れ込むパート番号（「… 2/4」）を落とす
      const t = (el.textContent || "").trim().replace(/\s*\d+\/\d+$/, "").trim();
      if (!t || seen.has(t)) continue;
      seen.add(t);
      parts.push(t);
    }
    return parts.join("\n").trim();
  }

  function extractMedia(root) {
    let count = 0;
    root.querySelectorAll("img").forEach((img) => {
      if (img.closest('a[href^="/@"]:not([href*="/post/"])')) return; // アバター
      const w = img.clientWidth || img.naturalWidth || 0;
      if (w > 80) count++;
    });
    count += root.querySelectorAll("video").length;
    return count;
  }

  function authorOf(root) {
    const a = root.querySelector('a[href^="/@"]:not([href*="/post/"])');
    if (!a) return null;
    const m = (a.getAttribute("href") || "").match(/^\/@([A-Za-z0-9._]+)/);
    return m ? m[1] : null;
  }

  // ピン留めの判定。
  // 「ピン留め済み」の表示が投稿の枠の外（少し上の階層）にある場合があるため、
  // 別の投稿を巻き込まない範囲（日時が1つのままの階層）まで見る。
  // ここを取りこぼすと、古いピン留めを「期間外まで到達」と誤解して
  // 走査が早期終了する不具合（1.0.5で修正）が再発する。
  function isPinned(root) {
    let el = root;
    for (let i = 0; i < 3 && el && el !== document.body; i++) {
      if (el.querySelectorAll("time[datetime]").length > 1) break;
      const hit = [...el.querySelectorAll("span,div")].some((n) =>
        PINNED.test((n.textContent || "").trim())
      );
      if (hit) return true;
      el = el.parentElement;
    }
    return false;
  }

  // 投稿ルートと抽出結果をまとめて返す（グループ化のためrootも持つ）
  function collectRaw() {
    const items = [];
    const seenCodes = new Set();
    const detail = detailTarget();
    let usedDetailCode = false;

    // 日時ごとに1投稿。document順に並ぶのでツリーの並び順もそのまま。
    document.querySelectorAll("time[datetime]").forEach((timeEl) => {
      const root = rootFromTime(timeEl);
      if (!root) return;

      const link = root.querySelector('a[href*="/post/"]');
      let sc = link ? shortcodeOf(link.getAttribute("href") || "") : null;

      // 詳細ページの本文の投稿は、枠の中にリンクを持たない
      // （リンクは「スレッド／表示◯回」の区画にある）。この1件だけURLから補う。
      if (!sc && detail && !usedDetailCode) {
        sc = { handle: detail.handle, code: detail.code };
        usedDetailCode = true;
      }
      if (!sc || seenCodes.has(sc.code)) return;
      seenCodes.add(sc.code);

      const { metrics, foundIcons } = extractMetrics(root);
      const text = extractText(root);

      items.push({
        root,
        post: {
          id: sc.code,
          url: `https://www.threads.com/@${sc.handle}/post/${sc.code}`,
          handle: sc.handle,
          author: authorOf(root) || sc.handle,
          text,
          charCount: text.length,
          likes: metrics.likes,
          replies: metrics.replies,
          reposts: metrics.reposts,
          shares: metrics.shares,
          datetime: timeEl ? timeEl.getAttribute("datetime") : null,
          mediaCount: extractMedia(root),
          isPinned: isPinned(root),
          _foundIcons: foundIcons,
        },
      });
    });

    return items;
  }

  function collectVisible() {
    return collectRaw().map((i) => i.post);
  }

  function hiddenPartsIn(el) {
    for (const node of el.querySelectorAll("span,div,a")) {
      const t = (node.textContent || "").trim();
      for (const re of SEE_MORE) {
        const m = t.match(re);
        if (m) return Number(m[1]) || 0;
      }
    }
    return 0;
  }

  // 2要素の共通祖先
  function lowestCommonAncestor(a, b) {
    let cur = a;
    while (cur && !cur.contains(b)) cur = cur.parentElement;
    return cur;
  }

  // ツリー1本ぶんの入れ物を返す。
  //   複数パート … 先頭と末尾の共通祖先
  //   1パート    … 他の投稿を巻き込まない範囲で最大の祖先
  // 「他N件を見る」をこの範囲だけで探すことで、隣のツリーの表示を拾わないようにする。
  function groupContainer(run) {
    if (run.length > 1) {
      return lowestCommonAncestor(run[0].root, run[run.length - 1].root) || run[0].root;
    }
    let el = run[0].root;
    for (let i = 0; i < 6; i++) {
      const parent = el.parentElement;
      if (!parent || parent === document.body) break;
      if (distinctCodes(parent).size > 1) break;
      el = parent;
    }
    return el;
  }

  // ツリー単位で収集する。プロフィールページ用。
  //
  // 判定の考え方：
  //   隣り合う2投稿が同じツリーなら、その共通祖先の中には
  //   その2投稿しか入っていない（ツリーの入れ物だから）。
  //   別々のツリーなら、共通祖先はフィード全体まで上がるので
  //   中に他の投稿がたくさん入る。
  //   これに「投稿者が同じ」を足して、ツリーの境界を決める。
  //
  // 以前はフィードの直下の子で区切っていたが、おすすめ投稿など
  // 別の場所にある投稿が混ざると基準の親が上に上がってしまい、
  // 別のツリーや他人の投稿まで1つの塊に入る不具合があったため、
  // 親要素に依存しないこの方式に変えた。
  //
  // プロフィールにはパート1〜2しか出ないので、
  //   表示されているパート数 + 「他N件を見る」のN = 総パート数
  // として、ツリーかどうかを推測ではなく確定させる。
  function collectGroups() {
    const items = collectRaw();
    if (!items.length) return [];

    const runs = [];
    let run = [];

    for (const it of items) {
      if (!run.length) {
        run = [it];
        continue;
      }

      const prev = run[run.length - 1];
      const sameAuthor = prev.post.author === it.post.author;
      const anc = lowestCommonAncestor(prev.root, it.root);
      // 共通祖先の中が、いま作りかけのツリーの投稿だけで収まっているか
      const selfContained = !!anc && distinctCodes(anc).size <= run.length + 1;

      if (sameAuthor && selfContained) {
        run.push(it);
      } else {
        runs.push(run);
        run = [it];
      }
    }
    if (run.length) runs.push(run);

    return runs.map((list) => {
      const parts = list.map((i) => i.post); // document順＝パート順
      const head = parts[0];
      const hidden = hiddenPartsIn(groupContainer(list));
      const partCount = parts.length + hidden;

      return {
        ...head,
        thread: {
          partCount,
          isThread: partCount > 1,
          parts: parts.map((p) => ({
            text: p.text,
            charCount: p.charCount,
            likes: p.likes,
            replies: p.replies,
            reposts: p.reposts,
            mediaCount: p.mediaCount,
            url: p.url,
            datetime: p.datetime,
            author: p.author, // 収集側で他人の投稿の混入を再確認するために持たせる
          })),
          fullText: parts.map((p) => p.text).filter(Boolean).join("\n\n"),
          totalChars: parts.reduce((a, p) => a + (p.charCount || 0), 0),
          hiddenParts: hidden,
          truncated: hidden > 0, // 続きは詳細ページを開かないと取れない
          source: "profile",
        },
      };
    });
  }

  // 詳細ページで、本人の連投だけを先頭から連続する範囲で取り出す。
  function collectThreadHere() {
    const target = detailTarget();
    if (!target) return null;

    const posts = collectVisible(); // document順
    const firstIdx = posts.findIndex((p) => p.id === target.code);
    if (firstIdx === -1) return null; // 起点が画面から消えている＝信用しない

    const parts = [];
    for (let i = firstIdx; i < posts.length; i++) {
      if (posts[i].author !== target.handle) break;
      parts.push(posts[i]);
    }
    if (!parts.length) return null;

    return { handle: target.handle, code: target.code, partCount: parts.length, parts };
  }

  function getScroller() {
    const doc = document.scrollingElement || document.documentElement;
    if (doc.scrollHeight > window.innerHeight + 50) return window;

    // ページ全体がスクロールしない作りの場合、スクロール可能な要素を探す
    const all = document.querySelectorAll("div,main,section");
    for (const el of all) {
      const style = getComputedStyle(el);
      if (/(auto|scroll)/.test(style.overflowY) && el.scrollHeight > el.clientHeight + 50) {
        return el;
      }
    }
    return window;
  }

  return {
    name: "Threads",
    isSupported,
    profileHandle,
    detailTarget,
    collectVisible,
    collectGroups,
    collectThreadHere,
    getScroller,
    metricKeys: ["likes", "replies", "reposts", "shares"],
    metricNames: { likes: "いいね", replies: "返信", reposts: "再投稿", shares: "共有" },
  };
})();
