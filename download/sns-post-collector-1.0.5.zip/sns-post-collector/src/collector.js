// スクロールしながら逐次収集するエンジン。
//
// Threads/Xは画面外の投稿をDOMから消す（仮想スクロール）ため、
// 「最後までスクロールしてから全部取る」ができない。少し進むごとに拾って貯める。
// 速度はあえて落としている（レート制限や過剰アクセスを避けるため）。
window.SPC = window.SPC || {};

SPC.collector = (() => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const state = {
    running: false,
    aborted: false,
    posts: new Map(),
    // 何が除外されたかを投稿IDで持つ。件数が少ないときに
    // 「不具合なのか、条件で絞られただけなのか」を画面で示すため。
    excluded: { author: new Set(), old: new Set() },
  };

  function scrollBy(scroller, amount) {
    if (scroller === window) window.scrollBy(0, amount);
    else scroller.scrollTop += amount;
  }

  function scrollTop(scroller) {
    if (scroller === window) window.scrollTo(0, 0);
    else scroller.scrollTop = 0;
  }

  // 同じ投稿を後で拾い直したとき、情報が多い方を残す。
  // ツリーのパート数が多い方を優先する（スクロール位置で見え方が変わるため）。
  function merge(existing, incoming) {
    if (!existing) return incoming;
    const score = (p) =>
      (p.thread ? p.thread.parts.length * 10000 : 0) +
      (p.likes != null ? 1000 : 0) +
      (p.datetime ? 500 : 0) +
      (p.text ? p.text.length : 0);
    return score(incoming) > score(existing) ? incoming : existing;
  }

  // 指定した垢の投稿かどうか。先頭だけでなくツリーの各パートも確認する。
  // グループ分けが何かの理由で崩れても、他人の投稿が混ざったまま
  // 出力されることがないようにするための二重チェック。
  function belongsTo(post, handle) {
    if (post.author !== handle) return false;
    const parts = post.thread && post.thread.parts;
    if (!parts) return true;
    return !parts.some((p) => p.author && p.author !== handle);
  }

  // 走査を打ち切るかどうかの判断。
  // ここは取りこぼしの原因になりやすいので、純粋な関数にしてテストできるようにしている。
  //   collected        いま集まった件数
  //   maxPosts         取得上限
  //   reachedOld       期間外の投稿まで到達したか（ピン留めは除く）
  //   idleRounds       新規ゼロが何周続いたか
  //   idleRoundsToStop 何周続いたら諦めるか
  function shouldStop({ collected, maxPosts, reachedOld, idleRounds, idleRoundsToStop }) {
    if (collected >= maxPosts) return "上限に到達";
    // 期間外まで来ていても、1回の空振りでは止めない（読み込み待ちのことがある）
    if (reachedOld && idleRounds >= 2) return "期間外まで到達";
    if (idleRounds >= idleRoundsToStop) return "新しい投稿が出てこない";
    return null;
  }

  function isTooOld(post, cutoffMs) {
    if (!cutoffMs || !post.datetime) return false;
    const t = Date.parse(post.datetime);
    return !Number.isNaN(t) && t < cutoffMs;
  }

  async function run(adapter, opts, onProgress) {
    const {
      delayMs = 1200,
      maxPosts = 200,
      sinceDays = 0,
      onlyAuthor = null,
      idleRoundsToStop = 6,
    } = opts || {};

    state.running = true;
    state.aborted = false;
    state.posts = new Map();
    state.excluded = { author: new Set(), old: new Set() };

    const cutoffMs = sinceDays > 0 ? Date.now() - sinceDays * 86400000 : 0;
    const scroller = adapter.getScroller();
    const step = Math.round(window.innerHeight * 0.75);

    scrollTop(scroller);
    await sleep(600);

    let idleRounds = 0;
    let rounds = 0;
    let reachedOld = false;

    while (state.running && !state.aborted) {
      rounds++;
      const before = state.posts.size;

      // プロフィールではツリー単位で拾う（パート2を別投稿として数えないため）
      const found = adapter.collectGroups
        ? adapter.collectGroups()
        : adapter.collectVisible();

      for (const post of found) {
        if (onlyAuthor && !belongsTo(post, onlyAuthor)) {
          state.excluded.author.add(post.id);
          continue;
        }
        if (isTooOld(post, cutoffMs)) {
          // ピン留めは古くても常に最上部に出る。これを「過去まで到達した」と
          // みなすと、走査開始直後に終了条件が成立してしまうので数に入れない。
          if (!post.isPinned) reachedOld = true;
          state.excluded.old.add(post.id);
          continue;
        }
        state.posts.set(post.id, merge(state.posts.get(post.id), post));
      }

      const gained = state.posts.size - before;
      idleRounds = gained > 0 ? 0 : idleRounds + 1;

      onProgress &&
        onProgress({
          collected: state.posts.size,
          rounds,
          idleRounds,
          status: "running",
        });

      const stopReason = shouldStop({
        collected: state.posts.size,
        maxPosts,
        reachedOld,
        idleRounds,
        idleRoundsToStop,
      });
      if (stopReason) break;

      scrollBy(scroller, step);
      // 新しい投稿が出てこないときは、読み込みを待つために間隔を伸ばす。
      // Threadsの遅延読み込みが遅れているだけの場合に取りこぼさないため。
      await sleep(idleRounds > 0 ? delayMs * (1 + idleRounds) : delayMs);
    }

    state.running = false;
    const posts = [...state.posts.values()].sort((a, b) => {
      const ta = a.datetime ? Date.parse(a.datetime) : 0;
      const tb = b.datetime ? Date.parse(b.datetime) : 0;
      return tb - ta;
    });

    onProgress &&
      onProgress({
        collected: posts.length,
        rounds,
        status: state.aborted ? "aborted" : "done",
      });

    return posts;
  }

  function stop() {
    state.aborted = true;
    state.running = false;
  }

  // 動作確認用。スクロールせず、いま見えている1件だけ返す。
  function sample(adapter) {
    const posts = adapter.collectVisible();
    return posts.length ? posts[0] : null;
  }

  return { run, stop, sample, state, belongsTo, shouldStop };
})();
