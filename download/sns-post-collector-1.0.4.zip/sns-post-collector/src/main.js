// エントリーポイント。アダプタを選び、役割を振り分ける。
//   プロフィールページ → 操作パネル
//   投稿詳細ページ     → ツリー全文の取得役（背景タブで開かれたとき）
(() => {
  const adapter = Object.values(SPC.adapters).find((a) => a.isSupported());
  if (!adapter) return;

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "SPC_TOGGLE_PANEL") SPC.panel.toggle(adapter);
    if (msg && msg.type === "SPC_FETCH_PROGRESS") SPC.panel.onFetchProgress(msg);
    if (msg && msg.type === "SPC_FETCH_DONE") SPC.panel.onFetchDone(msg);
  });

  // 詳細ページとして開かれた場合、自分がツリー取得の対象かを背景に確認する。
  // 対象でなければ何もしない（普通に閲覧しているときは動かない）。
  if (adapter.detailTarget()) {
    chrome.runtime
      .sendMessage({ type: "SPC_TAB_READY" })
      .then(async (res) => {
        if (!res || !res.collect) return;
        const data = await SPC.detail.run(adapter, {});
        chrome.runtime.sendMessage({ type: "SPC_THREAD_RESULT", data }).catch(() => {});
      })
      .catch(() => {});
    return;
  }

  // ThreadsはSPAなので、URLが変わっても再読み込みされない。
  // パネルを開いたまま別の垢に移動したときに対象表示を追従させる。
  let lastPath = location.pathname;
  setInterval(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      if (SPC.panel.isOpen()) SPC.panel.renderContext();
    }
  }, 800);
})();
