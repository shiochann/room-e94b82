// 投稿詳細ページ側の処理。ツリー全文を取りに行く担当。
//
// 背景でタブを開いて読み込ませ、本人の連投を先頭から順に集める。
// 仮想スクロールで下が読み込まれないので少しずつスクロールし、
// 「起点の投稿が画面にある状態で取れた最長のツリー」を採用する。
window.SPC = window.SPC || {};

SPC.detail = (() => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function run(adapter, opts) {
    const { rounds = 6, stepRatio = 0.6, waitMs = 700, readyTries = 20 } = opts || {};

    // 描画完了を待つ。SPAなのでcontent script起動時点では空のことがある。
    for (let i = 0; i < readyTries; i++) {
      if (adapter.collectThreadHere()) break;
      await sleep(400);
    }

    let best = null;
    let grewOnLastRound = false;

    for (let i = 0; i < rounds; i++) {
      const got = adapter.collectThreadHere();

      if (got) {
        if (!best || got.partCount > best.partCount) {
          best = got;
          grewOnLastRound = true;
        } else {
          grewOnLastRound = false;
        }
      }

      window.scrollBy(0, Math.round(window.innerHeight * stepRatio));
      await sleep(waitMs);
    }

    if (!best) return null;

    const parts = best.parts.map((p) => ({
      text: p.text,
      charCount: p.charCount,
      likes: p.likes,
      replies: p.replies,
      reposts: p.reposts,
      mediaCount: p.mediaCount,
      url: p.url,
      datetime: p.datetime,
    }));

    return {
      code: best.code,
      handle: best.handle,
      partCount: parts.length,
      isThread: parts.length > 1,
      parts,
      fullText: parts.map((p) => p.text).filter(Boolean).join("\n\n"),
      totalChars: parts.reduce((a, p) => a + (p.charCount || 0), 0),
      // 最後のラウンドでも伸び続けていた場合、まだ続きがある可能性がある
      truncated: grewOnLastRound,
    };
  }

  return { run };
})();
