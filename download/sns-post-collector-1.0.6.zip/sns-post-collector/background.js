// パネルの開閉と、ツリー全文取得のキュー管理。
//
// ツリー取得は「背景タブで投稿URLを開く → content scriptが読んで返す → タブを閉じる」を
// 1件ずつ順番に行う。同時に開かないのは、負荷をかけないためと確実性のため。

const jobs = new Map(); // tabId -> { resolve, url, timer }

// 背景タブはChromeによって大幅に減速される。
// 実測で setTimeout(400) が約1160ms、setTimeout(700) が約990msかかる
// （非表示タブのタイマーは概ね1秒間隔に間引かれる）。
// さらにページの読み込み自体も後回しにされるため、余裕を持たせる。
// ここが短いと「毎回すべて失敗」になる。
const TIMEOUT_MS = 60000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 拡張を入れる前から開いていたタブには、まだcontent scriptが入っていない。
// その状態でアイコンを押しても無反応になるので、
// 「送ってみる → 失敗したら注入してもう一度送る」の順で必ず起動させる。
// （購入者がページのリロードを知らなくても動くようにするため）
async function togglePanel(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "SPC_TOGGLE_PANEL" });
    return true;
  } catch {
    // まだ入っていないので注入する
  }

  try {
    // 注入するファイルはmanifestから読む（二重管理して食い違うのを防ぐ）
    const files = chrome.runtime.getManifest().content_scripts[0].js;
    await chrome.scripting.executeScript({ target: { tabId }, files });
    await chrome.tabs.sendMessage(tabId, { type: "SPC_TOGGLE_PANEL" });
    return true;
  } catch {
    // Threads以外のページ。ここでできることはない
    return false;
  }
}

chrome.action.onClicked.addListener((tab) => {
  if (tab.id) togglePanel(tab.id);
});

function fetchOne(url) {
  return new Promise((resolve) => {
    chrome.tabs
      .create({ url, active: false })
      .then((tab) => {
        const timer = setTimeout(() => finish(tab.id, null), TIMEOUT_MS);
        jobs.set(tab.id, { resolve, url, timer });
      })
      .catch(() => resolve(null));
  });
}

function finish(tabId, data) {
  const job = jobs.get(tabId);
  if (!job) return;
  clearTimeout(job.timer);
  jobs.delete(tabId);
  chrome.tabs.remove(tabId).catch(() => {});
  job.resolve(data);
}

async function runQueue(controllerTabId, urls, delayMs) {
  const results = [];

  for (let i = 0; i < urls.length; i++) {
    const data = await fetchOne(urls[i]);
    results.push({ url: urls[i], thread: data });

    chrome.tabs
      .sendMessage(controllerTabId, {
        type: "SPC_FETCH_PROGRESS",
        done: i + 1,
        total: urls.length,
        ok: !!data,
      })
      .catch(() => {});

    if (i < urls.length - 1) await sleep(delayMs);
  }

  chrome.tabs
    .sendMessage(controllerTabId, { type: "SPC_FETCH_DONE", results })
    .catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;

  // 詳細ページのcontent scriptが読み込み完了を知らせてくる。
  // キューに入っているタブなら「集めて返して」と応答する。
  // 作業中の合図。これを受け取ること自体が
  // サービスワーカーの停止を先延ばしにする（MV3は無操作だと止められる）。
  if (msg.type === "SPC_TAB_PING") {
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "SPC_TAB_READY") {
    const wanted = sender.tab && jobs.has(sender.tab.id);
    sendResponse({ collect: !!wanted });
    return;
  }

  if (msg.type === "SPC_THREAD_RESULT") {
    if (sender.tab) finish(sender.tab.id, msg.data);
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "SPC_FETCH_THREADS") {
    if (!sender.tab) {
      sendResponse({ started: false });
      return;
    }
    runQueue(sender.tab.id, msg.urls || [], msg.delayMs || 1500);
    sendResponse({ started: true });
    return;
  }
});
