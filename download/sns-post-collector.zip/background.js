// パネルの開閉と、ツリー全文取得のキュー管理。
//
// ツリー取得は「背景タブで投稿URLを開く → content scriptが読んで返す → タブを閉じる」を
// 1件ずつ順番に行う。同時に開かないのは、負荷をかけないためと確実性のため。

const jobs = new Map(); // tabId -> { resolve, url, timer }

// 背景タブはChromeによって大幅に減速される。
// 実測で setTimeout(400) が約1160ms、setTimeout(700) が約990msかかる
// （非表示タブのタイマーは概ね1秒間隔に間引かれる）。
// さらにページの読み込み自体も後回しにされるため、余裕を持たせる。
// ここが短いと「毎回すべて失敗」になる。
const TIMEOUT_MS = 60000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ツリー取得の列が動いているか。
// MV3のサービスワーカーは、約30秒なにも起きないとChromeに停止される。
// 停止されると、この変数も待ち時間のタイマーも消え、列は二度と進まない。
// パネル側がこれを定期的に問い合わせて、止まっていないか確かめる。
let queueActive = false;

// 拡張を入れる前から開いていたタブには、まだcontent scriptが入っていない。
// その状態でアイコンを押しても無反応になるので、
// 「送ってみる → 失敗したら注入してもう一度送る」の順で必ず起動させる。
// （購入者がページのリロードを知らなくても動くようにするため）
async function togglePanel(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "SPC_TOGGLE_PANEL" });
    return true;
  } catch {
    // まだ入っていないので注入する
  }

  try {
    // 注入するファイルはmanifestから読む（二重管理して食い違うのを防ぐ）
    const files = chrome.runtime.getManifest().content_scripts[0].js;
    await chrome.scripting.executeScript({ target: { tabId }, files });
    await chrome.tabs.sendMessage(tabId, { type: "SPC_TOGGLE_PANEL" });
    return true;
  } catch {
    // Threads以外のページ。ここでできることはない
    return false;
  }
}

chrome.action.onClicked.addListener((tab) => {
  if (tab.id) togglePanel(tab.id);
});

function fetchOne(url) {
  return new Promise((resolve) => {
    chrome.tabs
      .create({ url, active: false })
      .then((tab) => {
        const timer = setTimeout(() => finish(tab.id, null), TIMEOUT_MS);
        jobs.set(tab.id, { resolve, url, timer });
      })
      .catch(() => resolve(null));
  });
}

function finish(tabId, data) {
  const job = jobs.get(tabId);
  if (!job) return;
  clearTimeout(job.timer);
  jobs.delete(tabId);
  chrome.tabs.remove(tabId).catch(() => {});
  job.resolve(data);
}

async function runQueue(controllerTabId, urls, delayMs) {
  const results = [];
  queueActive = true;
  try {

  for (let i = 0; i < urls.length; i++) {
    // 開始時にも知らせる。1件目が終わるまで表示が変わらないと
    // 「固まった」ように見えてしまうため（1件に最大60秒かかる）。
    chrome.tabs
      .sendMessage(controllerTabId, {
        type: "SPC_FETCH_PROGRESS",
        done: i,
        total: urls.length,
        starting: true,
      })
      .catch(() => {});

    const data = await fetchOne(urls[i]);
    results.push({ url: urls[i], thread: data });

    chrome.tabs
      .sendMessage(controllerTabId, {
        type: "SPC_FETCH_PROGRESS",
        done: i + 1,
        total: urls.length,
        ok: !!data,
      })
      .catch(() => {});

    if (i < urls.length - 1) await sleep(delayMs);
  }
  } finally {
    queueActive = false;
  }

  chrome.tabs
    .sendMessage(controllerTabId, { type: "SPC_FETCH_DONE", results })
    .catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;

  // パネルからの生存確認。
  // 受け取ること自体がサービスワーカーの停止を先延ばしにし、
  // 返す値で「列がまだ動いているか」を伝える。
  if (msg.type === "SPC_KEEPALIVE") {
    sendResponse({ active: queueActive });
    return;
  }

  // 詳細ページからの作業中の合図。受け取ること自体が
  // サービスワーカーの停止を先延ばしにする（MV3は無操作だと止められる）。
  if (msg.type === "SPC_TAB_PING") {
    sendResponse({ ok: true });
    return;
  }

  // 詳細ページのcontent scriptが読み込み完了を知らせてくる。
  // キューに入っているタブなら「集めて返して」と応答する。
  if (msg.type === "SPC_TAB_READY") {
    const wanted = sender.tab && jobs.has(sender.tab.id);
    sendResponse({ collect: !!wanted });
    return;
  }

  if (msg.type === "SPC_THREAD_RESULT") {
    if (sender.tab) finish(sender.tab.id, msg.data);
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "SPC_FETCH_THREADS") {
    if (!sender.tab) {
      sendResponse({ started: false });
      return;
    }
    runQueue(sender.tab.id, msg.urls || [], msg.delayMs || 1500);
    sendResponse({ started: true });
    return;
  }
});
