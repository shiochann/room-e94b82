// 投稿詳細ページ側の処理。ツリー全文を取りに行く担当。
//
// 背景でタブを開いて読み込ませ、本人の連投を先頭から順に集める。
// 仮想スクロールで下が読み込まれないので少しずつスクロールし、
// 「起点の投稿が画面にある状態で取れた最長のツリー」を採用する。
window.SPC = window.SPC || {};

SPC.detail = (() => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // 作業中だと背景に知らせる。MV3のサービスワーカーが途中で止まるのを防ぐ。
  function ping() {
    try {
      chrome.runtime.sendMessage({ type: "SPC_TAB_PING" }).catch(() => {});
    } catch {
      /* 接続が切れていても続行する */
    }
  }

  async function run(adapter, opts) {
    // 背景タブではタイマーが約1秒間隔に間引かれるため、
    // 「何回試すか」ではなく「いつまで待つか」で管理する。
    const {
      rounds = 6,
      stepRatio = 0.6,
      waitMs = 700,
      readyBudgetMs = 20000,
      totalBudgetMs = 45000,
    } = opts || {};

    const startedAt = Date.now();
    const overBudget = () => Date.now() - startedAt > totalBudgetMs;

    // 描画完了を待つ。SPAなのでcontent script起動時点では空のことがある。
    const readyDeadline = Date.now() + readyBudgetMs;
    while (Date.now() < readyDeadline) {
      if (adapter.collectThreadHere()) break;
      ping();
      await sleep(400);
    }

    let best = null;
    let grewOnLastRound = false;
    let stableRounds = 0;

    for (let i = 0; i < rounds; i++) {
      const got = adapter.collectThreadHere();

      if (got) {
        if (!best || got.partCount > best.partCount) {
          best = got;
          grewOnLastRound = true;
          stableRounds = 0;
        } else {
          grewOnLastRound = false;
          stableRounds++;
        }
      }

      // これ以上増えないと分かった時点で切り上げる。
      // 背景タブは1周ごとに約1秒かかるので、無駄な周回を減らす。
      if (best && stableRounds >= 2) break;
      if (overBudget()) break;

      window.scrollBy(0, Math.round(window.innerHeight * stepRatio));
      ping();
      await sleep(waitMs);
    }

    if (!best) return null;

    const parts = best.parts.map((p) => ({
      text: p.text,
      charCount: p.charCount,
      likes: p.likes,
      replies: p.replies,
      reposts: p.reposts,
      mediaCount: p.mediaCount,
      url: p.url,
      datetime: p.datetime,
    }));

    return {
      code: best.code,
      handle: best.handle,
      partCount: parts.length,
      isThread: parts.length > 1,
      parts,
      fullText: parts.map((p) => p.text).filter(Boolean).join("\n\n"),
      totalChars: parts.reduce((a, p) => a + (p.charCount || 0), 0),
      // 最後のラウンドでも伸び続けていた場合、まだ続きがある可能性がある
      truncated: grewOnLastRound,
    };
  }

  return { run };
})();
