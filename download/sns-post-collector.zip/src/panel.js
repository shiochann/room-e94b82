// 画面に浮かせる操作パネル。
// ポップアップだとスクロール収集中に閉じてしまうので、ページ内に置く。
// Shadow DOMに入れてThreads側のCSSと干渉させない。
window.SPC = window.SPC || {};

SPC.panel = (() => {
  const { format } = SPC.num;
  const { summarize } = SPC.stats;
  const out = SPC.output;

  let host = null;
  let root = null;
  let adapter = null;

  const state = {
    posts: [],
    scanned: 0,
    dist: null,
    replyDist: null,
    fetching: false,
    warnings: [],
  };

  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif; }
    .wrap {
      position: fixed; top: 16px; right: 16px; width: 340px; max-height: 88vh;
      overflow-y: auto; z-index: 2147483647;
      background: #fff; color: #16181c;
      border: 1px solid #d7dbdf; border-radius: 14px;
      box-shadow: 0 8px 32px rgba(0,0,0,.18);
      font-size: 13px; line-height: 1.6;
    }
    @media (prefers-color-scheme: dark) {
      .wrap { background: #17181a; color: #e8e9ea; border-color: #33363a; }
      .box { background: #1f2124 !important; border-color: #33363a !important; }
      input, select { background: #17181a !important; color: #e8e9ea !important; border-color: #44474b !important; }
      .btn.sub { background: #26282b !important; color: #e8e9ea !important; border-color: #44474b !important; }
      .hint { color: #9aa0a6 !important; }
    }
    .head {
      display: flex; align-items: center; justify-content: space-between;
      padding: 12px 14px; border-bottom: 1px solid rgba(128,128,128,.25);
      position: sticky; top: 0; background: inherit; border-radius: 14px 14px 0 0;
    }
    .title { font-weight: 700; font-size: 13px; }
    .close { cursor: pointer; border: 0; background: transparent; font-size: 18px; color: inherit; line-height: 1; padding: 0 4px; }
    .body { padding: 14px; }
    .sec { margin-bottom: 16px; }
    .sec:last-child { margin-bottom: 0; }
    .lbl { font-weight: 600; font-size: 12px; margin-bottom: 6px; display: block; }
    .row { display: flex; gap: 8px; align-items: center; margin-bottom: 8px; }
    .row > label { flex: 1; font-size: 12px; }
    input[type="number"], select {
      width: 88px; padding: 5px 7px; border: 1px solid #d7dbdf;
      border-radius: 7px; font-size: 12px;
    }
    select { width: 118px; }
    .btn {
      display: block; width: 100%; padding: 9px; border: 0; border-radius: 9px;
      font-size: 13px; font-weight: 600; cursor: pointer;
      background: #16181c; color: #fff; margin-bottom: 7px;
    }
    .btn:hover { opacity: .88; }
    .btn.sub { background: #f2f3f5; color: #16181c; border: 1px solid #d7dbdf; }
    .btn:disabled { opacity: .45; cursor: not-allowed; }
    .box {
      background: #f7f8f9; border: 1px solid #e5e7ea;
      border-radius: 9px; padding: 10px; font-size: 12px;
    }
    .box.warn { background: #fff6e5; border-color: #f0c987; color: #6b4a00; }
    .box.err  { background: #ffe9e9; border-color: #f0a0a0; color: #7a1f1f; }
    .num { font-variant-numeric: tabular-nums; font-weight: 700; }
    .hint { color: #6b7075; font-size: 11px; margin-top: 5px; }
    .radio { display: flex; align-items: center; gap: 7px; margin-bottom: 5px; font-size: 12px; cursor: pointer; }
    .radio input { margin: 0; }
    .hit { font-weight: 700; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
    pre {
      margin: 6px 0 0; padding: 8px; background: rgba(128,128,128,.12);
      border-radius: 7px; font-size: 11px; white-space: pre-wrap;
      word-break: break-all; max-height: 190px; overflow-y: auto;
      font-family: ui-monospace, monospace;
    }
    .hidden { display: none !important; }
  `;

  const HTML = `
    <div class="wrap">
      <div class="head">
        <span class="title">SNS投稿コレクター</span>
        <button class="close" title="閉じる">×</button>
      </div>
      <div class="body">

        <div class="sec" id="ctx"></div>

        <div class="sec">
          <span class="lbl">収集の設定</span>
          <div class="row"><label>取得上限</label><input type="number" id="maxPosts" value="120" min="10" max="1000" step="10"></div>
          <div class="row"><label>期間</label>
            <select id="sinceDays">
              <option value="0">すべて</option>
              <option value="30">直近30日</option>
              <option value="90" selected>直近90日</option>
              <option value="180">直近180日</option>
            </select>
          </div>
          <div class="row"><label>スクロール速度</label>
            <select id="delayMs">
              <option value="1800">ゆっくり</option>
              <option value="1200" selected>標準</option>
              <option value="700">速い</option>
            </select>
          </div>
          <div class="row">
            <label for="onlyAuthor">この垢の投稿だけ</label>
            <input type="checkbox" id="onlyAuthor" checked style="width:auto">
          </div>
          <div class="hint">速度を上げると取りこぼしや制限を受けやすくなります。標準のままを推奨。</div>
        </div>

        <div class="sec">
          <button class="btn sub" id="sampleBtn">まず1件だけ試し取得</button>
          <button class="btn" id="startBtn">走査を開始</button>
          <button class="btn sub hidden" id="stopBtn">停止</button>
          <div id="progress" class="box hidden"></div>
        </div>

        <div class="sec hidden" id="sampleOut"></div>

        <div class="sec hidden" id="distSec">
          <span class="lbl">いいねの分布</span>
          <div class="box" id="distBox"></div>
        </div>

        <div class="sec hidden" id="filterSec">
          <span class="lbl">絞り込み</span>
          <label class="radio"><input type="radio" name="mode" value="median2" checked><span>中央値の2倍以上</span></label>
          <label class="radio"><input type="radio" name="mode" value="p80"><span>上位20%</span></label>
          <label class="radio"><input type="radio" name="mode" value="manual"><span>自分で指定</span></label>
          <div class="row"><label>いいね ≧</label><input type="number" id="minLikes" value="20" min="0"></div>
          <div class="row"><label>返信 ≧</label><input type="number" id="minReplies" value="0" min="0"></div>
          <label class="radio"><input type="radio" name="mode" value="none"><span>絞り込みなし</span></label>
          <div class="box" id="hitBox" style="margin-top:8px"></div>
        </div>

        <div class="sec hidden" id="threadSec">
          <span class="lbl">ツリー全文の取得</span>
          <div class="box">プロフィールにはツリーの1本目しか出ません。全文と「ツリーか単発か」は、投稿を開かないと確定しません。</div>
          <div id="noTextWarn"></div>
          <button class="btn" id="fetchThreads" style="margin-top:8px">該当分のツリー全文を取得</button>
          <button class="btn sub" id="copyUrls">URL一覧をコピー</button>
          <div id="fetchProgress" class="box hidden"></div>
          <div class="hint">1件ずつ背景タブで開いて閉じます。1件あたり4〜6秒。件数が多いときは絞ってから。</div>
        </div>

        <div class="sec hidden" id="outSec">
          <span class="lbl">書き出し</span>
          <div id="outWhy"></div>
          <div id="truncWarn"></div>
          <button class="btn" id="copyPrompt">分析プロンプトをコピー</button>
          <div id="promptSize"></div>
          <div id="splitBox"></div>
          <div class="grid">
            <button class="btn sub" id="copyMd">Markdownをコピー</button>
            <button class="btn sub" id="saveMd">.md 保存</button>
            <button class="btn sub" id="copyCsv">CSVをコピー</button>
            <button class="btn sub" id="saveCsv">.csv 保存</button>
          </div>
          <div class="hint">プロンプトはClaudeやChatGPTに貼るだけ。拡張はAIを呼ばないので費用はかかりません。</div>
        </div>

      </div>
    </div>
  `;

  const $ = (sel) => root.querySelector(sel);

  function mount(adapterRef) {
    if (host) return;
    adapter = adapterRef;

    // コードが二重に注入された場合、前回のパネルが残っていると
    // 操作の効かないパネルが二つ並ぶので、古い方を消してから作る。
    const stale = document.getElementById("spc-panel-host");
    if (stale) stale.remove();

    host = document.createElement("div");
    host.id = "spc-panel-host";
    root = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = CSS;
    root.appendChild(style);

    const container = document.createElement("div");
    container.innerHTML = HTML;
    root.appendChild(container);

    document.documentElement.appendChild(host);
    wire();
    renderContext();
  }

  function toggle(adapterRef) {
    if (!host) {
      mount(adapterRef);
      return;
    }
    host.style.display = host.style.display === "none" ? "" : "none";
    if (host.style.display !== "none") renderContext();
  }

  function isOpen() {
    return !!host && host.style.display !== "none";
  }

  function renderContext() {
    const handle = adapter.profileHandle();
    if (handle) {
      $("#ctx").innerHTML = `<div class="box">対象: <span class="num">@${handle}</span>（${adapter.name}）</div>`;
      $("#startBtn").disabled = false;
    } else {
      $("#ctx").innerHTML =
        `<div class="box warn">プロフィールページで開いてください。<div class="hint">例: threads.com/@アカウント名</div></div>`;
      $("#startBtn").disabled = true;
    }
  }

  // 抽出が正しく効いているか目で確認するための表示。
  // ここが合っていないと分布も絞り込みも無意味になるので、最初に必ず見る。
  function renderSample() {
    const target = $("#onlyAuthor").checked ? adapter.profileHandle() : null;
    const p = SPC.collector.sample(adapter, target);
    const el = $("#sampleOut");
    el.classList.remove("hidden");

    if (!p) {
      el.innerHTML = `<div class="box err">投稿を1件も認識できませんでした。<div class="hint">投稿が表示されている状態か確認してください。表示されているのに失敗する場合、Threads側の構造が変わった可能性があります。</div></div>`;
      return;
    }

    // 画面に投稿はあるが、対象アカウントのものが無い場合
    if (p.empty) {
      el.innerHTML = p.sawOthers
        ? `<div class="box warn">この垢の投稿が画面上に見つかりませんでした。<div class="hint">おすすめなど他の垢の投稿だけが映っているようです。ページを一番上まで戻してから、もう一度お試しください。</div></div>`
        : `<div class="box err">投稿を1件も認識できませんでした。<div class="hint">投稿が表示されている状態か確認してください。</div></div>`;
      return;
    }

    const missing = adapter.metricKeys.filter((k) => p[k] == null);
    const warn = missing.length
      ? `<div class="box warn" style="margin-top:6px">取得できなかった項目: ${missing
          .map((k) => adapter.metricNames[k])
          .join("、")}<div class="hint">この項目での絞り込みは正しく動きません。</div></div>`
      : `<div class="box" style="margin-top:6px">4項目すべて取得できています。</div>`;

    el.innerHTML = `
      <span class="lbl">試し取得の結果</span>
      <div class="box">
        <div class="hint" style="margin:0 0 6px">
          ${out.kindLabel(p)}${p.isPinned ? "・ピン留め" : ""}／
          <a href="${p.url}" target="_blank" rel="noopener">この投稿を開く</a>
        </div>
        いいね <span class="num">${format(p.likes)}</span> ／
        返信 <span class="num">${format(p.replies)}</span> ／
        再投稿 <span class="num">${format(p.reposts)}</span><br>
        日時 ${out.jpDate(p.datetime)}／文字数 ${p.charCount}／画像 ${p.mediaCount ? "有" : "無"}
        <pre>${escapeHtml(p.text || "(本文を取得できませんでした)")}</pre>
      </div>
      ${warn}
      <div class="hint">
        「この投稿を開く」で実際の投稿と見比べてください。<br>
        <strong>数字が合っていればOKです。</strong>どの投稿が選ばれるかは画面の位置で変わります
        （ピン留めがあると、それが選ばれます）。
      </div>
    `;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
    );
  }

  async function start() {
    const opts = {
      maxPosts: Number($("#maxPosts").value) || 120,
      sinceDays: Number($("#sinceDays").value) || 0,
      delayMs: Number($("#delayMs").value) || 1200,
      onlyAuthor: $("#onlyAuthor").checked ? adapter.profileHandle() : null,
    };

    $("#startBtn").classList.add("hidden");
    $("#stopBtn").classList.remove("hidden");
    $("#sampleBtn").disabled = true;
    $("#progress").classList.remove("hidden");

    // 走査が途中で失敗しても、必ず操作できる状態に戻す。
    // 以前は失敗すると「走査中…」の表示のまま固まり、
    // 「特定の垢だけ動かない」という症状になっていた。
    let posts = [];
    try {
      posts = await SPC.collector.run(adapter, opts, (p) => {
        $("#progress").innerHTML =
          p.status === "running"
            ? `走査中… 取得 <span class="num">${p.collected}</span>ツリー<div class="hint">このタブを前面にしたままにしてください。別のタブやアプリに切り替えると、本文が取れなくなります。停止したいときは停止ボタン。</div>`
            : `走査${p.status === "aborted" ? "を中断" : "完了"}: <span class="num">${p.collected}</span>ツリー` +
              (p.errors ? `<div class="hint">${p.errors}件は読み取れずに飛ばしました。</div>` : "");
      });
    } catch (e) {
      SPC.collector.stop();
      $("#progress").innerHTML =
        `<div class="box err">走査を続けられませんでした。` +
        `<div class="hint">${escapeHtml(String(e && e.message ? e.message : e))}` +
        `<br>ページを再読み込みしてからもう一度お試しください。何度も起きる場合は、この文言を添えてご連絡ください。</div></div>`;
    } finally {
      $("#startBtn").classList.remove("hidden");
      $("#stopBtn").classList.add("hidden");
      $("#sampleBtn").disabled = false;
    }

    if (!posts.length && SPC.collector.state.errors && SPC.collector.state.errors.length) {
      return; // 何も取れず、原因は上に表示済み
    }

    state.posts = posts;
    state.scanned = posts.length;
    state.dist = summarize(posts.map((p) => p.likes));
    state.replyDist = summarize(posts.map((p) => p.replies));

    renderDist();
    renderFilter();
  }

  function renderDist() {
    const d = state.dist;
    $("#distSec").classList.remove("hidden");

    const failed = state.posts.filter((p) => p.likes == null).length;
    const warn = failed
      ? `<div class="hint" style="color:#b06000">${failed}件はいいね数を取得できませんでした（絞り込みでは除外されます）。</div>`
      : "";

    const threads = state.posts.filter((p) => p.thread && p.thread.isThread).length;
    const solo = state.posts.filter((p) => p.thread && !p.thread.isThread).length;
    const pinned = state.posts.filter((p) => p.isPinned).length;

    // ピン留めは表示期間が長いぶん数値が積み上がるので、分布を上に引っ張る
    const pinNote = pinned
      ? `<div class="hint">ピン留め ${pinned}件を含みます（表示期間が長く数値が積み上がるため、分布を上に引っ張ります）。</div>`
      : "";

    // 収集の単位はツリーなので、投稿数とは一致しない。
    // 件数が少ないときに誤解されるので、両方と除外の内訳を出す。
    const postCount = state.posts.reduce(
      (a, p) => a + (p.thread ? p.thread.parts.length : 1),
      0
    );
    const ex = SPC.collector.state.excluded;
    const exParts = [];
    if (ex.old.size) exParts.push(`期間外 ${ex.old.size}件`);
    if (ex.author.size) exParts.push(`他の垢の投稿 ${ex.author.size}件`);
    const exNote = exParts.length
      ? `<div class="hint">除外: ${exParts.join(" / ")}（設定を変えれば含められます）</div>`
      : "";

    $("#distBox").innerHTML = `
      走査 <span class="num">${state.scanned}</span>ツリー（投稿 <span class="num">${postCount}</span>件）<br>
      内訳 ツリー <span class="num">${threads}</span> / 単発 <span class="num">${solo}</span><br>
      ${exNote}
      中央値 <span class="num">${format(d.median)}</span> ／
      上位20% <span class="num">${format(d.p80)}</span> ／
      最大 <span class="num">${format(d.max)}</span>
      <div class="hint">数値はパート1（ツリーの1本目）のものです。</div>
      ${pinNote}
      ${warn}
    `;

    // 分布を見てから閾値を決められるよう、既定値を実データから入れる
    if (d.median != null) $("#minLikes").value = Math.max(1, d.median * 2);
  }

  function threshold() {
    const mode = [...root.querySelectorAll('input[name="mode"]')].find((r) => r.checked).value;
    const d = state.dist;
    if (mode === "none") return { min: 0, label: "絞り込みなし" };
    if (mode === "median2")
      return { min: (d.median ?? 0) * 2, label: `いいね ${format((d.median ?? 0) * 2)}以上（中央値の2倍）` };
    if (mode === "p80") return { min: d.p80 ?? 0, label: `いいね ${format(d.p80)}以上（上位20%）` };
    return { min: Number($("#minLikes").value) || 0, label: `いいね ${$("#minLikes").value}以上` };
  }

  function filtered() {
    const { min } = threshold();
    const minRep = Number($("#minReplies").value) || 0;
    return state.posts.filter((p) => {
      if (p.likes == null) return false;
      if (p.likes < min) return false;
      if (minRep > 0 && (p.replies ?? 0) < minRep) return false;
      return true;
    });
  }

  function filterLabel() {
    const t = threshold();
    const minRep = Number($("#minReplies").value) || 0;
    return minRep > 0 ? `${t.label} かつ 返信${minRep}以上` : t.label;
  }

  function renderFilter() {
    $("#filterSec").classList.remove("hidden");
    $("#threadSec").classList.remove("hidden");
    $("#outSec").classList.remove("hidden");

    const hits = filtered();
    $("#hitBox").innerHTML = `走査 <span class="num">${state.scanned}</span>件 → 該当 <span class="hit num">${hits.length}</span>件`;

    const disabled = hits.length === 0;
    ["#copyPrompt", "#copyMd", "#saveMd", "#copyCsv", "#saveCsv", "#copyUrls"].forEach((s) => {
      $(s).disabled = disabled;
    });

    // ボタンが灰色のまま押せない理由を必ず言葉で出す。
    // 黙って無効になっていると「保存できない＝故障」と受け取られるため。
    const noLikes = state.posts.filter((p) => p.likes == null).length;
    $("#outWhy").innerHTML = !disabled
      ? ""
      : `<div class="box warn">該当が0件のため書き出せません。
          <div class="hint">絞り込みを緩めてください（「絞り込みなし」か「自分で指定」で数字を下げる）。${
            noLikes ? `<br>なお、いいね数を取得できなかった${noLikes}件は絞り込みの対象外になっています。` : ""
          }</div></div>`;

    // 続きが隠れているもの＋本文が取れていないものを開きに行く
    const pending = needFetch(hits).length;
    const noText = hits.filter((p) => !bodyText(p)).length;
    const est = Math.ceil((pending * 5) / 60);

    $("#fetchThreads").disabled = disabled || pending === 0 || state.fetching;
    $("#fetchThreads").textContent = state.fetching
      ? "取得中…"
      : pending === 0
      ? `全文は揃っています（${hits.length}件）`
      : `${pending}件の本文を取得（約${est}分）`;

    renderPromptSize(hits);

    // ウィンドウが狭いと、本文の続きがそもそもページ上に無い。
    // 展開用のリンクは存在しないので、幅を広げて取り直すしかない。
    //
    // 以前は「もっと見る」という文字で1件ずつ判定していたが、それは誤りだった。
    // 各投稿の「⋯」メニューのアイコンにも同じラベルが付いているため、
    // 全投稿が該当してしまい、常に警告が出ていた。
    $("#truncWarn").innerHTML =
      adapter.isNarrow && adapter.isNarrow()
        ? `<div class="box warn">ウィンドウが狭いため、本文が途中までになっている可能性があります。
            <div class="hint">Threadsは幅が狭いと本文の続きを表示しません（開くボタンもありません）。
            <strong>ウィンドウを最大化して走査し直す</strong>と全文が取れます。
            このままなら「本文を取得」で1件ずつ取り直せます。</div></div>`
        : "";

    // 本文が空のまま出力すると分析できないので、必ず気づけるようにする
    $("#noTextWarn").innerHTML = noText
      ? `<div class="box warn">本文が取れていない投稿が <span class="num">${noText}</span> 件あります。` +
        `<div class="hint">上のボタンで取り直せます。走査中にこのタブが裏に回ると起きやすいので、次回は前面のままお試しください。</div></div>`
      : "";
  }

  // プロンプトの分量を出す。
  // AIの入力欄には貼り付けられる量に上限があり、超えると黙って切られる。
  // 「切れているのに気づかない」のが一番まずいので、押す前に見せる。
  const PROMPT_LIMIT = 25000;

  function renderPromptSize(hits) {
    const sizeEl = $("#promptSize");
    const splitEl = $("#splitBox");
    if (!hits.length) {
      sizeEl.innerHTML = "";
      splitEl.innerHTML = "";
      return;
    }

    const len = out.prompt(hits, meta()).length;
    const over = len > PROMPT_LIMIT;

    sizeEl.innerHTML = over
      ? `<div class="box warn">プロンプトは約 <span class="num">${format(len)}</span> 字です。
          <div class="hint">AIによっては貼り付けきれず、<strong>途中で切れることがあります。</strong>
          下のボタンで分けて貼るか、絞り込みを厳しくして件数を減らしてください。</div></div>`
      : `<div class="hint">プロンプトは約 ${format(len)} 字です。</div>`;

    if (!over) {
      splitEl.innerHTML = "";
      return;
    }

    const chunks = out.promptChunks(hits, meta(), PROMPT_LIMIT);
    splitEl.innerHTML =
      `<div class="hint" style="margin-bottom:6px">分けてコピー（上から順に貼ってください）</div>` +
      chunks
        .map(
          (c, i) =>
            `<button class="btn sub" data-chunk="${i}">${i + 1}/${chunks.length} をコピー（約${format(c.length)}字）</button>`
        )
        .join("");

    splitEl.querySelectorAll("button[data-chunk]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const list = out.promptChunks(filtered(), meta(), PROMPT_LIMIT);
        copyText(list[Number(btn.dataset.chunk)], e.target.closest("button"));
      });
    });
  }

  // プロフィールで全パート見えているものは開く必要がない
  // 詳細ページを開いて取り直す対象。
  // 「続きが隠れている」ものに加えて、本文が空のものも対象にする。
  // 走査中に描画が追いつかず本文だけ取れないことがあり、
  // そのまま出力すると分析できないため、ここで回収できるようにしている。
  function needFetch(posts) {
    return posts.filter((p) => !p.thread || p.thread.truncated || !bodyText(p));
  }

  // その投稿の本文（ツリーなら全文）。空文字なら未取得。
  function bodyText(p) {
    if (p.thread && p.thread.fullText) return p.thread.fullText.trim();
    return (p.text || "").trim();
  }

  async function fetchThreads() {
    const targets = needFetch(filtered());
    if (!targets.length) return;

    state.fetching = true;
    renderFilter();
    $("#fetchProgress").classList.remove("hidden");
    $("#fetchProgress").innerHTML = `準備中… 0/${targets.length}`;

    await chrome.runtime.sendMessage({
      type: "SPC_FETCH_THREADS",
      urls: targets.map((p) => p.url),
      delayMs: 1500,
    });
  }

  function onFetchProgress(msg) {
    if (!root) return;

    // 開始の合図と完了の合図で表示を変える。
    // 1件に最大1分かかるので、何件目を処理中なのかを常に出しておく。
    const label = msg.starting
      ? `${msg.done + 1}件目を取得中… <span class="num">${msg.done}</span> / ${msg.total} 完了`
      : `取得中 <span class="num">${msg.done}</span> / ${msg.total}`;

    $("#fetchProgress").innerHTML =
      label +
      `<div class="hint">1件あたり最大1分かかることがあります。背景タブが開閉しますが、` +
      `このタブは開いたままにしてください。</div>`;
  }

  function onFetchDone(msg) {
    if (!root) return;
    state.fetching = false;

    const byUrl = new Map(state.posts.map((p) => [p.url, p]));
    let ok = 0;
    let ng = 0;

    for (const r of msg.results || []) {
      const post = byUrl.get(r.url);
      if (!post) continue;
      if (r.thread) {
        // 詳細ページで取れた全文で置き換える。プロフィール側で分かっている
        // 総パート数の方が多い場合は、そちらを正として残す。
        const known = post.thread ? post.thread.partCount : 0;
        post.thread = {
          ...r.thread,
          partCount: Math.max(r.thread.partCount, known),
          isThread: Math.max(r.thread.partCount, known) > 1,
          hiddenParts: Math.max(0, known - r.thread.partCount),
          source: "detail",
        };
        ok++;
      } else {
        ng++;
      }
    }

    const stillShort = state.posts.filter((p) => p.thread && p.thread.hiddenParts > 0).length;

    $("#fetchProgress").innerHTML =
      `取得完了: 成功 <span class="num">${ok}</span>件` +
      (ng ? ` / 失敗 <span class="num">${ng}</span>件` : "") +
      (stillShort ? `<div class="hint">${stillShort}件はまだ全パート揃っていません（長いツリー）。</div>` : "") +
      (ng ? `<div class="hint">失敗した投稿は全文が1本目のみになります。種類は「?」のままにして推測では埋めません。</div>` : "");

    renderFilter();
  }

  function meta() {
    return {
      platform: adapter.name,
      handle: adapter.profileHandle() || "unknown",
      scanned: state.scanned,
      dist: state.dist,
      filterLabel: filterLabel(),
    };
  }

  async function copyText(text, btn) {
    const original = btn.textContent;
    try {
      await navigator.clipboard.writeText(text);
      btn.textContent = "コピーしました";
    } catch {
      // クリップボードが拒否された場合の保険
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      btn.textContent = ok ? "コピーしました" : "コピー失敗";
    }
    setTimeout(() => (btn.textContent = original), 1600);
  }

  // 保存。押した結果が分かるよう、ボタンの文言で必ず知らせる。
  // 黙って何も起きないと「保存できない」と受け取られるため。
  function download(text, filename, mime, btn) {
    const original = btn ? btn.textContent : null;
    try {
      const blob = new Blob([text], { type: `${mime};charset=utf-8` });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      // 一度ページに置いてから押す（切り離したままだと弾かれる環境がある）
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);

      if (btn) {
        btn.textContent = "保存しました";
        setTimeout(() => (btn.textContent = original), 1800);
      }
    } catch (e) {
      if (btn) {
        btn.textContent = "保存できません";
        setTimeout(() => (btn.textContent = original), 2400);
      }
    }
  }

  function stamp() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`;
  }

  function wire() {
    $(".close").addEventListener("click", () => (host.style.display = "none"));
    $("#sampleBtn").addEventListener("click", renderSample);
    $("#startBtn").addEventListener("click", start);
    $("#stopBtn").addEventListener("click", () => SPC.collector.stop());

    root.querySelectorAll('input[name="mode"]').forEach((r) =>
      r.addEventListener("change", renderFilter)
    );
    $("#minLikes").addEventListener("input", () => {
      const manual = root.querySelector('input[name="mode"][value="manual"]');
      manual.checked = true;
      renderFilter();
    });
    $("#minReplies").addEventListener("input", renderFilter);

    $("#fetchThreads").addEventListener("click", fetchThreads);
    $("#copyUrls").addEventListener("click", (e) => copyText(out.urlList(filtered()), e.target));

    $("#copyPrompt").addEventListener("click", (e) =>
      copyText(out.prompt(filtered(), meta()), e.target)
    );
    $("#copyMd").addEventListener("click", (e) =>
      copyText(out.markdown(filtered(), meta()), e.target)
    );
    $("#copyCsv").addEventListener("click", (e) => copyText(out.csv(filtered()), e.target));
    $("#saveMd").addEventListener("click", (e) =>
      download(
        out.markdown(filtered(), meta()),
        `${meta().handle}_${stamp()}.md`,
        "text/markdown",
        e.target.closest("button")
      )
    );
    $("#saveCsv").addEventListener("click", (e) =>
      download(out.csv(filtered()), `${meta().handle}_${stamp()}.csv`, "text/csv",
        e.target.closest("button"))
    );
  }

  return { mount, toggle, isOpen, renderContext, onFetchProgress, onFetchDone };
})();
